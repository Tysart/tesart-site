
document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const strip = document.querySelector('.pages-strip');
  const pages = Array.from(document.querySelectorAll('.page[data-page]'));

  if (!strip || pages.length === 0) {
    console.warn('[spa] strip/pages not found');
    return;
  }

  /* =========================
     CONFIG
  ========================= */
  const PAGE_CLASSES = ['is-home', 'is-portfolio', 'is-blog', 'is-about', 'is-inner'];
  
  /* =========================
     HELPERS
  ========================= */
  function setBodyPageClass(pageId) {
    PAGE_CLASSES.forEach(c => body.classList.remove(c));
    body.classList.add(`is-${pageId}`);

    if (pageId !== 'home') body.classList.add('is-inner');
    else body.classList.remove('is-inner');
  }

  function setActiveNav(pageId) {
    document.querySelectorAll('.nav-pill').forEach(btn => {
      btn.classList.toggle('nav-pill--active', btn.dataset.target === pageId);
    });
  }

  function setActivePage(pageId) {
    pages.forEach(p =>
      p.classList.toggle('is-active', p.dataset.page === pageId)
    );
  }

  /* =========================
     CORE NAVIGATION
  ========================= */
  function goToPage(pageId, { instant = false } = {}) {
    const index = pages.findIndex(p => p.dataset.page === pageId);
    if (index === -1) return;

    // управление transition
    strip.style.transition = instant ? 'none' : 'transform .55s cubic-bezier(.19,1,.22,1)';

const current = document.querySelector('.page.is-active')?.dataset.page || 'home';
const isLeavingHome = current === 'home' && pageId !== 'home';
const isGoingHome = current !== 'home' && pageId === 'home';

const lamp = document.querySelector('.inner-lamp');

// прячем хром только если реально пересекаем границу home <-> inner
if (isLeavingHome || isGoingHome) {
  body.classList.add('chrome-hidden');
}

    // двигаем ленту
    strip.style.transform = `translateX(${-index * 100}%)`;

    setBodyPageClass(pageId);
    setActiveNav(pageId);
    setActivePage(pageId);

    // после завершения слайда — показываем хром (если не home)
    const onDone = () => {
      strip.removeEventListener('transitionend', onDone);

// показываем хром только если пришли на inner из home
if (isLeavingHome) {
  body.classList.remove('chrome-hidden');
}

// --- Lamp control ---
if (lamp) {
  if (pageId === 'home') {
    lamp.classList.remove('is-on');
  } else {
    // позиция лампы = текущая страница
    // index: 0 home, 1 portfolio, 2 blog, 3 about
    lamp.style.left = `${index * 100}%`;

    // "включение" с микрозадержкой, чтобы совпало с ощущением перехода
    lamp.classList.remove('is-on');
    requestAnimationFrame(() => {
      requestAnimationFrame(() => lamp.classList.add('is-on'));
    });
  }
}

// если пришли на home — оставляем скрытым (там он и должен быть скрыт)
if (pageId === 'home') {
  body.classList.add('chrome-hidden');
}

      // перепривязка автоскролла
      if (window.__bindChromeScroller) {
        const active = document.querySelector('.page.is-active');
        const scroller = active?.querySelector('.page-body') || active;
        window.__bindChromeScroller(scroller);
      }
    };

    strip.addEventListener('transitionend', onDone, { once: true });

    // вернуть transition, если instant
if (instant) {
  requestAnimationFrame(() => {
    strip.style.transition = 'transform .55s cubic-bezier(.19,1,.22,1)';
    if (pageId === 'home') body.classList.add('chrome-hidden');
    else body.classList.remove('chrome-hidden');
  });
}
  }

  /* =========================
     EVENT DELEGATION (кнопки)
  ========================= */
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.js-goto');
    if (!btn) return;

    e.preventDefault();
    const target = btn.dataset.target;
    if (!target) return;

    goToPage(target);
  });

  /* =========================
     START PAGE
  ========================= */
  let startPage = 'home';
  if (body.classList.contains('is-portfolio')) startPage = 'portfolio';
  if (body.classList.contains('is-blog')) startPage = 'blog';
  if (body.classList.contains('is-about')) startPage = 'about';

  goToPage(startPage, { instant: true });
});

/* =========================
   AUTO-HIDE CHROME ON SCROLL
========================= */
(function setupChromeAutoHide() {
  const THRESHOLD = 12;
  let lastY = 0;
  let acc = 0;
  let currentScroller = null;

  function bindTo(scroller) {
    if (!scroller || scroller === currentScroller) return;

    currentScroller = scroller;
    lastY = scroller.scrollTop || 0;
    acc = 0;

    scroller.addEventListener('scroll', () => {
      const y = scroller.scrollTop || 0;
      const dy = y - lastY;
      lastY = y;

      if (y <= 2) {
        document.body.classList.remove('chrome-hidden');
        acc = 0;
        return;
      }

      acc += dy;

      if (acc > THRESHOLD) {
        document.body.classList.add('chrome-hidden');
        acc = 0;
      } else if (acc < -THRESHOLD) {
        document.body.classList.remove('chrome-hidden');
        acc = 0;
      }
    }, { passive: true });
  }

  window.__bindChromeScroller = bindTo;
})();


(function initVideoModalUniversal() {
  const modal = document.getElementById('videoModal');
  const frame = document.getElementById('videoModalFrame');

  const mYear  = document.getElementById('videoModalYear');
  const mTitle = document.getElementById('videoModalTitle');
  const mDesc  = document.getElementById('videoModalDesc');

  if (!modal || !frame) {
    console.warn('[modal] #videoModal or #videoModalFrame not found');
    return;
  }

  let currentList = [];
  let currentIndex = -1;

  function stopVideo() { frame.src = ''; }

  function withAutoplay(url) {
    if (!url) return '';
    if (/autoplay=1/.test(url)) return url;
    return url + (url.includes('?') ? '&' : '?') + 'autoplay=1';
  }

  function openEl(el, index) {
  currentIndex = index;

  const url = (el.dataset.video || '').trim();

  const year  = (el.dataset.year  || el.querySelector('.video-year,.lesson-kicker')?.textContent || '').trim();
  const title = (el.dataset.title || el.querySelector('.video-title,.lesson-title,h2,h3')?.textContent || '').trim();
  const desc  = (el.dataset.desc  || el.querySelector('.video-desc,.lesson-desc,p')?.textContent || '').trim();

  if (mYear)  mYear.textContent = year;
  if (mTitle) mTitle.textContent = title;
  if (mDesc)  mDesc.textContent = desc;

  // 1) сначала открываем модалку
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');

  // 2) потом (на следующий кадр) ставим src
  stopVideo();
  requestAnimationFrame(() => {
    // важно: иногда помогает "пересоздать" src строго после display:block
    frame.src = url;
  });
}

  function openByIndex(i) {
    if (!currentList.length) return;
    if (i < 0) i = currentList.length - 1;
    if (i >= currentList.length) i = 0;
    openEl(currentList[i], i);
  }

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    stopVideo();
    document.body.classList.remove('modal-open');
  }

  function next() { openByIndex(currentIndex + 1); }
  function prev() { openByIndex(currentIndex - 1); }

  // ---------------------------
  // CLICK HANDLER (Portfolio + Blog)
  // ---------------------------
  document.addEventListener('click', (e) => {
    // 1) BLOG: lesson-card
    const lessonCard = e.target.closest('#blog-lessons .lesson-card[data-video]');
    if (lessonCard) {
      const wrap = document.getElementById('blog-lessons');
      if (!wrap) return;

      currentList = Array.from(wrap.querySelectorAll('.lesson-card[data-video]'))
        .filter(el => (el.dataset.video || '').trim().length > 0);

      const idx = currentList.indexOf(lessonCard);
      if (idx === -1) return;

      openEl(lessonCard, idx);
      return;
    }

    // 2) PORTFOLIO: video-card (учитываем фильтр .is-hidden)
    const card = e.target.closest('#portfolio-grid .video-card[data-video]');
    if (card) {
      const grid = document.getElementById('portfolio-grid');
      if (!grid) return;

      currentList = Array.from(grid.querySelectorAll('.video-card[data-video]'))
        .filter(el => !el.classList.contains('is-hidden'))
        .filter(el => (el.dataset.video || '').trim().length > 0);

      const idx = currentList.indexOf(card);
      if (idx === -1) return;

      openEl(card, idx);
      return;
    }
  });

  // ---------------------------
  // MODAL CONTROLS
  // ---------------------------
  modal.addEventListener('click', (e) => {
    if (e.target.closest('[data-modal-close]')) closeModal();
    if (e.target.closest('[data-modal-next]')) next();
    if (e.target.closest('[data-modal-prev]')) prev();
  });

  document.addEventListener('keydown', (e) => {
    if (!modal.classList.contains('is-open')) return;
    if (e.key === 'Escape') closeModal();
    if (e.key === 'ArrowRight') next();
    if (e.key === 'ArrowLeft') prev();
  });
})();

(function initPortfolioFilters() {
  const grid = document.getElementById('portfolio-grid');
  const filters = document.getElementById('portfolio-filters');
  if (!grid || !filters) {
    console.warn('[filters] #portfolio-grid or #portfolio-filters not found');
    return;
  }

  function norm(s) {
    return (s || '').toString().trim().toLowerCase();
  }

  filters.addEventListener('click', (e) => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;

    const filter = norm(btn.dataset.filter || 'all');

    // active state
    filters.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('is-active'));
    btn.classList.add('is-active');

    // show/hide cards
    grid.querySelectorAll('.video-card').forEach(card => {
      const cat = norm(card.dataset.category || '');
      const ok = (filter === 'all') || cat.includes(filter);
      card.classList.toggle('is-hidden', !ok);
    });
  });
})();


(function mobileScrollDarken(){
  if (window.innerWidth > 900) return;

  const overlay = document.querySelector('.home-darken');
  if (!overlay) return;

  let startY = 0;
  let current = 0;
  const MAX = 0.55;      // максимум затемнения
  const TRIGGER = 0.45;  // порог для перехода

  window.addEventListener('touchstart', e => {
    startY = e.touches[0].clientY;
  }, { passive: true });

  window.addEventListener('touchmove', e => {
    const y = e.touches[0].clientY;
    const delta = startY - y;

    if (delta <= 0) return;

    current = Math.min(delta / 400, MAX);
    overlay.style.background = `rgba(0,0,0,${current})`;
  }, { passive: true });

  window.addEventListener('touchend', () => {
    if (current > TRIGGER) {
      const btn = document.querySelector('.js-goto[data-target="portfolio"]');
      if (btn) btn.click();
    }

    // сброс
    overlay.style.background = 'rgba(0,0,0,0)';
    current = 0;
  });
})();