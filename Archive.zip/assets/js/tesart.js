document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const strip = document.querySelector('.pages-strip');
  const pages = Array.from(document.querySelectorAll('.page'));
  const navButtons = document.querySelectorAll('.js-goto');

  if (!strip || !pages.length) return;

  // geometry in %
  strip.style.display = 'flex';
  strip.style.willChange = 'transform';
  strip.style.transition = 'transform 0.55s cubic-bezier(.19,1,.22,1)';
  strip.style.width = `${pages.length * 100}%`;

  pages.forEach(p => {
    p.style.flex = '0 0 100%';
    p.style.width = '100%';
  });

  const PAGE_CLASSES = ['is-home', 'is-portfolio', 'is-blog', 'is-about', 'is-inner', 'is-nav-ready'];

  let isAnimating = false;

  function setBodyPage(pageId) {
    PAGE_CLASSES.forEach(cls => body.classList.remove(cls));
    body.classList.add(`is-${pageId}`);
    if (pageId !== 'home') body.classList.add('is-inner');
  }

  function setActiveTabs(pageId) {
    document.querySelectorAll('.nav-pill').forEach(btn => {
      btn.classList.toggle('nav-pill--active', btn.dataset.target === pageId);
    });
  }

  function goToPage(pageId) {
    if (isAnimating) return;

    const index = pages.findIndex(p => p.dataset.page === pageId);
    if (index === -1) return;

    isAnimating = true;

    // before move: hide nav (so no jump)
    body.classList.remove('is-nav-ready');

    // move
    strip.style.transform = `translateX(${-index * 100}%)`;

    const onEnd = (e) => {
      if (e.propertyName !== 'transform') return;
      strip.removeEventListener('transitionend', onEnd);

      setBodyPage(pageId);
      setActiveTabs(pageId);

      // show nav only after slide finished
      if (pageId !== 'home') {
        requestAnimationFrame(() => body.classList.add('is-nav-ready'));
      }

      isAnimating = false;
    };

    strip.addEventListener('transitionend', onEnd);
  }

  navButtons.forEach(btn => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      const target = btn.dataset.target;
      if (target) goToPage(target);
    });
  });

  // initial
  let startPage = 'home';
  if (body.classList.contains('is-portfolio')) startPage = 'portfolio';
  if (body.classList.contains('is-blog')) startPage = 'blog';
  if (body.classList.contains('is-about')) startPage = 'about';

  // set start instantly without animation flash
  strip.style.transition = 'none';
  strip.style.transform = `translateX(${-pages.findIndex(p => p.dataset.page === startPage) * 100}%)`;
  setBodyPage(startPage);
  setActiveTabs(startPage);
  if (startPage !== 'home') body.classList.add('is-nav-ready');

  // restore animation
  requestAnimationFrame(() => {
    strip.style.transition = 'transform 0.55s cubic-bezier(.19,1,.22,1)';
  });
});