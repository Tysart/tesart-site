// Parallax (hero film strip)
document.addEventListener('DOMContentLoaded', () => {
  const strip = document.querySelector('.hero-film-strip');
  if (!strip) return;

  const strength = 26;

  function handleMove(event) {
    const w = window.innerWidth;
    const h = window.innerHeight;

    const xNorm = (event.clientX / w) - 0.5;
    const yNorm = (event.clientY / h) - 0.5;

    const xOffset = -xNorm * strength;
    const yOffset = -yNorm * strength;

    strip.style.transform =
      `translate(calc(-50% + ${xOffset}px), calc(-50% + ${yOffset}px)) rotate(-4deg)`;
  }

  // Desktop — параллакс от мыши
  window.addEventListener('mousemove', handleMove);

  // Mobile — лёгкий параллакс от скролла (на всякий случай)
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY || window.pageYOffset || 0;
    const smallOffset = scrollY * 0.03;

    strip.style.transform =
      `translate(-50%, calc(-50% + ${smallOffset}px)) rotate(-4deg)`;
  });
});